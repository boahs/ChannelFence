(function initializeChannelFenceContent() {
  "use strict";

  const Shared = globalThis.ChannelFenceShared;
  if (!Shared || globalThis.__channelFenceLoaded) {
    return;
  }
  globalThis.__channelFenceLoaded = true;

  const CONTENT_SELECTOR = [
    "ytd-rich-item-renderer",
    "ytd-video-renderer",
    "ytd-grid-video-renderer",
    "ytd-compact-video-renderer",
    "ytd-playlist-video-renderer",
    "ytd-playlist-panel-video-renderer",
    "ytd-reel-item-renderer",
    "ytd-reel-video-renderer",
    "ytm-shorts-lockup-view-model",
    "ytm-shorts-lockup-view-model-v2",
    "ytd-channel-renderer",
    "ytd-radio-renderer",
    "yt-lockup-view-model",
    ".yt-lockup-view-model",
    ".yt-lockup-view-model--wrapper",
    "ytm-video-with-context-renderer",
    "ytm-compact-video-renderer"
  ].join(",");

  const COMMENT_SELECTOR = [
    "ytd-comment-thread-renderer",
    "ytd-comment-view-model",
    "ytm-comment-thread-renderer"
  ].join(",");

  const MENU_POPUP_SELECTOR = [
    "ytd-menu-popup-renderer",
    "yt-sheet-view-model"
  ].join(",");

  const PROMOTED_CONTENT_SELECTOR = [
    "ytd-ad-slot-renderer",
    "ytd-in-feed-ad-layout-renderer",
    "ytd-promoted-video-renderer",
    "ytd-display-ad-renderer",
    "ytd-banner-promo-renderer"
  ].join(",");

  const SHORTS_SHELF_SELECTOR = [
    "ytd-reel-shelf-renderer",
    "ytd-rich-shelf-renderer[is-shorts]",
    "yt-horizontal-list-renderer[is-shorts]",
    "grid-shelf-view-model"
  ].join(",");

  const SHORTS_CARD_SELECTOR = [
    "ytd-reel-item-renderer",
    "ytm-shorts-lockup-view-model",
    "ytm-shorts-lockup-view-model-v2",
    "ytd-rich-item-renderer",
    "ytd-video-renderer",
    "ytd-grid-video-renderer",
    "ytd-compact-video-renderer",
    "yt-lockup-view-model",
    ".yt-lockup-view-model",
    ".yt-lockup-view-model--wrapper",
    "ytm-video-with-context-renderer",
    "ytm-compact-video-renderer"
  ].join(",");

  const CHANNEL_ANCHOR_SELECTOR = [
    "a#avatar-link[href]",
    "ytd-channel-name a[href]",
    "#channel-name a[href]",
    "a#author-text[href]",
    "#owner-name a[href]",
    "a.yt-simple-endpoint[href^='/@']",
    "a.yt-simple-endpoint[href^='/channel/']",
    "a.yt-simple-endpoint[href^='/c/']",
    "a.yt-simple-endpoint[href^='/user/']",
    "a[href^='/@']",
    "a[href^='/channel/']",
    "a[href^='/c/']",
    "a[href^='/user/']",
    "a[href^='https://www.youtube.com/@']",
    "a[href^='https://www.youtube.com/channel/']",
    "a[href^='https://www.youtube.com/c/']",
    "a[href^='https://www.youtube.com/user/']",
    "a[href^='https://youtube.com/@']",
    "a[href^='https://youtube.com/channel/']",
    "a[href^='https://m.youtube.com/@']",
    "a[href^='https://m.youtube.com/channel/']",
    "yt-lockup-view-model a[href]",
    ".yt-lockup-view-model a[href]",
    ".yt-lockup-view-model--wrapper a[href]",
    "[class*='metadata-view-model'] a[href]"
  ].join(",");

  const OWNER_CHANNEL_ANCHOR_SELECTOR = [
    "a#avatar-link[href]",
    "ytd-channel-name a[href]",
    "#channel-name a[href]",
    "a#author-text[href]",
    "#owner-name a[href]",
    "#channel-info a[href]",
    ".ytLockupMetadataViewModelAvatar a[href]",
    ".ytContentMetadataViewModelMetadataRow:first-child a[href]",
    "yt-content-metadata-view-model .ytContentMetadataViewModelMetadataRow:first-child a[href]"
  ].join(",");

  const LINKLESS_LOCKUP_CREATOR_SELECTOR = [
    ".ytContentMetadataViewModelMetadataRow:first-child .ytContentMetadataViewModelMetadataTextFirstPart",
    ".ytContentMetadataViewModelMetadataRow:first-child .ytContentMetadataViewModelMetadataTextLastPart",
    ".ytContentMetadataViewModelMetadataRow:first-child [role='text']"
  ].join(",");

  const LINKLESS_LOCKUP_CREATOR_ROW_SELECTOR =
    ".ytContentMetadataViewModelMetadataRow:first-child";

  const LINKLESS_LOCKUP_AVATAR_SELECTOR =
    ".ytLockupMetadataViewModelAvatar [aria-label^='Go to channel ']";

  const COMPACT_SHORTS_SELECTOR =
    "ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2";

  const PAGE_OWNER_SELECTORS = [
    "ytd-shorts ytd-reel-video-renderer",
    "ytd-shorts yt-reel-channel-bar-view-model",
    "yt-reel-channel-bar-view-model",
    "yt-page-header-renderer",
    "ytd-c4-tabbed-header-renderer #channel-header-container",
    "ytd-watch-metadata #owner",
    "ytd-video-owner-renderer",
    "ytd-channel-name#channel-name",
    "ytd-reel-video-renderer[is-active]",
    "ytm-slim-owner-renderer"
  ];

  const PAGE_OWNER_SELECTOR = PAGE_OWNER_SELECTORS.join(",");
  const MUTATION_ROOT_SELECTOR = [
    CONTENT_SELECTOR,
    COMMENT_SELECTOR,
    MENU_POPUP_SELECTOR
  ].join(",");
  const SHORTS_VISIBILITY_SELECTOR = [
    SHORTS_SHELF_SELECTOR,
    SHORTS_CARD_SELECTOR,
    "ytd-rich-section-renderer",
    ".cf-hidden-shorts-by-channelfence"
  ].join(",");

  const state = {
    enabled: true,
    hideComments: true,
    hideHomeShorts: false,
    blocked: [],
    blockedKeys: new Set(),
    currentUrl: location.href,
    scanScheduled: false,
    mutationScanScheduled: false,
    mutationRoots: new Set(),
    mutationShortsRoots: new Set(),
    mutationRouteDirty: false,
    menuScanScheduled: false,
    navigationInProgress: false,
    pendingMenuContext: null,
    pendingTimer: null,
    blockedShortSkipKey: "",
    blockedShortSkipTimer: null,
    compactShortContexts: new Map(),
    compactShortLookups: new Map(),
    compactShortFailures: new Map(),
    toastTimer: null
  };

  function isShortsRoute() {
    return location.pathname === "/shorts" || location.pathname.startsWith("/shorts/");
  }

  function isWatchLikeRoute() {
    return location.pathname === "/watch" || isShortsRoute();
  }

  function routeHasCurrentCreator() {
    return isWatchLikeRoute() || Boolean(Shared.normalizeChannelRef(location.href));
  }

  function markWatchPending() {
    clearTimeout(state.pendingTimer);
    if (!state.enabled || state.blocked.length === 0 || !isWatchLikeRoute()) {
      document.documentElement.classList.remove("cf-watch-pending");
      return;
    }
    document.documentElement.classList.add("cf-watch-pending");
    state.pendingTimer = setTimeout(() => {
      document.documentElement.classList.remove("cf-watch-pending");
    }, 4500);
  }

  function clearWatchPending() {
    clearTimeout(state.pendingTimer);
    document.documentElement.classList.remove("cf-watch-pending");
  }

  function rebuildBlockedKeys() {
    state.blocked = Shared.sanitizeBlockedEntries(state.blocked);
    state.blockedKeys = new Set(state.blocked.flatMap((entry) => entry.aliases));
  }

  function requestActionUpdate() {
    chrome.runtime.sendMessage({ type: "CF_SYNC_ACTION" }).catch(() => undefined);
  }

  async function loadState() {
    const values = await chrome.storage.local.get(Object.keys(Shared.DEFAULTS));
    state.enabled = values[Shared.STORAGE.enabled] !== false;
    state.hideComments = values[Shared.STORAGE.hideComments] !== false;
    state.hideHomeShorts = values[Shared.STORAGE.hideHomeShorts] === true;
    state.blocked = values[Shared.STORAGE.blocked] || [];
    rebuildBlockedKeys();
  }

  async function initializeState() {
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        await loadState();
        markWatchPending();
        requestActionUpdate();
        scheduleScan();
        return;
      } catch {
        await new Promise((resolve) => setTimeout(resolve, 150 * (attempt + 1)));
      }
    }
    // Keep the default enabled/empty state usable if Chrome is still settling
    // immediately after a fresh unpacked install. Storage changes will sync in.
    scheduleScan();
  }

  function channelAnchorsFromElement(root) {
    if (!root || typeof root.querySelectorAll !== "function") {
      return [];
    }

    const normalizedAnchors = (selector) => [...root.querySelectorAll(selector)].filter((anchor) => {
      if (anchor.closest("#cf-hard-block-overlay, #cf-toast")) {
        return false;
      }
      return Boolean(Shared.normalizeChannelRef(
        anchor.href || anchor.getAttribute("href"),
        location.href
      ));
    });

    // Prefer links in known uploader/owner containers. The broad fallback is
    // needed for new YouTube renderers, but can also include @mentions in a
    // description, which must not become aliases of the uploader.
    const ownerAnchors = normalizedAnchors(OWNER_CHANNEL_ANCHOR_SELECTOR);
    return ownerAnchors.length > 0
      ? ownerAnchors
      : normalizedAnchors(CHANNEL_ANCHOR_SELECTOR);
  }

  function displayNameFromAnchor(anchor, ref) {
    const candidates = [
      anchor?.textContent,
      anchor?.getAttribute?.("aria-label"),
      anchor?.getAttribute?.("title"),
      ref?.type === "handle" ? ref.value : ""
    ];
    for (const candidate of candidates) {
      const name = Shared.cleanCreatorDisplayName(candidate);
      if (name) {
        return name;
      }
    }
    return ref?.value || "creator";
  }

  function anchorPlacementScore(anchor) {
    if (!anchor) {
      return 0;
    }
    const hasLayout = anchor.getClientRects().length > 0;
    const hasText = Boolean(Shared.cleanCreatorDisplayName(anchor.textContent));
    return (hasLayout ? 10 : 0) + (hasText ? 2 : 0) +
      (anchor.getAttribute("aria-label") ? 1 : 0);
  }

  function ownerContextsFromElement(root) {
    const contexts = new Map();
    for (const anchor of channelAnchorsFromElement(root)) {
      const ref = Shared.normalizeChannelRef(
        anchor.href || anchor.getAttribute("href"),
        location.href
      );
      if (!ref) {
        continue;
      }

      const displayName = displayNameFromAnchor(anchor, ref);
      const normalizedName = Shared.normalizeCreatorName(displayName);
      const contextKey = normalizedName || ref.key;
      const existing = contexts.get(contextKey);
      if (existing) {
        existing.refs = Shared.uniqueRefs([...existing.refs, ref]);
        if (anchorPlacementScore(anchor) > anchorPlacementScore(existing.anchor)) {
          existing.anchor = anchor;
          existing.displayName = displayName;
        }
        continue;
      }
      contexts.set(contextKey, {
        refs: [ref],
        displayName,
        anchor
      });
    }

    if (contexts.size === 0) {
      for (const name of linklessLockupCreatorNames(root)) {
        const ref = Shared.normalizeCreatorNameRef(name);
        if (ref) {
          contexts.set(ref.key, { refs: [ref], displayName: name, anchor: null });
        }
      }
    }
    return [...contexts.values()];
  }

  function refsFromElement(root) {
    if (!root || typeof root.querySelectorAll !== "function") {
      return [];
    }

    const refs = [];
    if (root.matches && root.matches("a[href]")) {
      const own = Shared.normalizeChannelRef(root.href || root.getAttribute("href"), location.href);
      if (own) {
        refs.push(own);
      }
    }

    for (const context of ownerContextsFromElement(root)) {
      refs.push(...context.refs);
      if (refs.length >= 8) {
        break;
      }
    }
    return Shared.uniqueRefs(refs);
  }

  function ownerNamesFromElement(root) {
    if (!root || typeof root.querySelectorAll !== "function") {
      return [];
    }

    const names = new Set();
    for (const context of ownerContextsFromElement(root)) {
      const normalized = Shared.normalizeCreatorName(context.displayName);
      if (normalized) {
        names.add(normalized);
      }
    }

    for (const name of linklessLockupCreatorNames(root)) {
      const normalized = Shared.normalizeCreatorName(name);
      if (normalized) {
        names.add(normalized);
      }
    }

    for (const name of collaborationNamesFromElement(root)) {
      const normalized = Shared.normalizeCreatorName(name);
      if (normalized) {
        names.add(normalized);
      }
    }
    return [...names];
  }

  function collaborationNamesFromElement(root) {
    if (!root?.querySelector?.(
      "yt-avatar-stack-view-model[aria-label*='Collaboration' i]"
    )) {
      return [];
    }

    const label = [...root.querySelectorAll("#attributed-channel-name")]
      .map((element) => Shared.cleanCreatorDisplayName(element.textContent))
      .find((name) => /\s(?:and|&)\s|,/.test(name));
    if (!label) {
      return [];
    }

    return label
      .split(/\s+(?:and|&)\s+|,\s*/i)
      .map((name) => Shared.cleanCreatorDisplayName(name))
      .filter(Boolean)
      .slice(0, 8);
  }

  function isLockupRoot(root) {
    return Boolean(root?.matches?.(
      "yt-lockup-view-model, .yt-lockup-view-model, .yt-lockup-view-model--wrapper"
    ));
  }

  function linklessLockupCreatorElements(root) {
    if (!isLockupRoot(root) || typeof root.querySelectorAll !== "function") {
      return [];
    }
    const metadata = [...root.querySelectorAll(LINKLESS_LOCKUP_CREATOR_SELECTOR)];
    const row = root.querySelector(LINKLESS_LOCKUP_CREATOR_ROW_SELECTOR);
    const avatar = root.querySelector(LINKLESS_LOCKUP_AVATAR_SELECTOR);
    return [...metadata, row, avatar].filter(Boolean);
  }

  function cleanLinklessLockupCreatorName(value) {
    const name = Shared.cleanCreatorDisplayName(value)
      .replace(/\s+[·•]\s*(?:course|playlist|podcast)\s*$/i, "")
      .trim();
    if (!name || /^(?:course|playlist|podcast|view full course|\d+\s+lessons?)$/i.test(name)) {
      return "";
    }
    return name;
  }

  function linklessLockupCreatorLabel(element) {
    const accessibilityLabel = element.getAttribute("aria-label") || element.getAttribute("title");
    if (accessibilityLabel) {
      return accessibilityLabel;
    }
    const copy = element.cloneNode(true);
    copy.querySelectorAll?.(".cf-block-button, .cf-shorts-action, .cf-menu-item")
      .forEach((control) => control.remove());
    return copy.textContent || "";
  }

  function linklessLockupCreatorNames(root) {
    const names = [];
    const seen = new Set();
    for (const element of linklessLockupCreatorElements(root)) {
      const name = cleanLinklessLockupCreatorName(linklessLockupCreatorLabel(element));
      const normalized = Shared.normalizeCreatorName(name);
      if (normalized && !seen.has(normalized)) {
        seen.add(normalized);
        names.push(name);
      }
    }
    return names;
  }

  function refsWithNameFallback(refs, displayName) {
    const stableRefs = Shared.uniqueRefs(refs);
    if (stableRefs.length > 0) {
      return stableRefs;
    }
    return Shared.uniqueRefs([Shared.normalizeCreatorNameRef(displayName)]);
  }

  function metadataRefs() {
    const refs = [];
    const channelId = document.querySelector("meta[itemprop='channelId'][content]")?.content;
    if (channelId) {
      const ref = Shared.normalizeChannelRef(`/channel/${channelId}`, location.href);
      if (ref) {
        refs.push(ref);
      }
    }
    return refs;
  }

  function elementVisibilityScore(element) {
    if (!element || typeof element.getBoundingClientRect !== "function") {
      return 0;
    }
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") {
      return -1;
    }

    const rect = element.getBoundingClientRect();
    const hasArea = rect.width > 0 && rect.height > 0;
    const inViewport = hasArea && rect.bottom > 0 && rect.right > 0 &&
      rect.top < innerHeight && rect.left < innerWidth;
    return (hasArea ? 10 : 0) + (inViewport ? 20 : 0) +
      (element.hasAttribute("is-active") ? 8 : 0);
  }

  function pageOwnerRoot() {
    let best = null;
    let bestScore = -Infinity;
    PAGE_OWNER_SELECTORS.forEach((selector, selectorIndex) => {
      for (const candidate of document.querySelectorAll(selector)) {
        const hasIdentity = refsFromElement(candidate).length > 0 ||
          Boolean(Shared.cleanCreatorDisplayName(candidate.textContent));
        if (!hasIdentity) {
          continue;
        }
        const score = (elementVisibilityScore(candidate) * 100) - selectorIndex;
        if (score > bestScore) {
          best = candidate;
          bestScore = score;
        }
      }
    });
    return best;
  }

  function currentPageContext() {
    if (!routeHasCurrentCreator()) {
      return { refs: [], displayName: "", owners: [] };
    }

    const refs = [];
    const pathRef = Shared.normalizeChannelRef(location.href);
    if (pathRef) {
      refs.push(pathRef);
    }
    refs.push(...metadataRefs());

    const owner = pageOwnerRoot();
    const owners = owner ? ownerContextsFromElement(owner) : [];
    if (owner) {
      refs.push(...refsFromElement(owner));
    }

    const cleanRefs = Shared.uniqueRefs(refs);
    const nameSelectors = [
      "ytd-watch-metadata #owner #channel-name a",
      "#owner-name a",
      "yt-page-header-renderer h1",
      "ytd-c4-tabbed-header-renderer #channel-name",
      "ytd-reel-video-renderer[is-active] #channel-name",
      "ytd-reel-video-renderer[is-active] a[href^='/@']"
    ];
    let displayName = owners[0]?.displayName || "";
    for (const selector of nameSelectors) {
      if (displayName) {
        break;
      }
      displayName = Shared.cleanDisplayName(document.querySelector(selector)?.textContent);
      if (displayName) {
        break;
      }
    }

    return {
      refs: cleanRefs,
      displayName: displayName || (cleanRefs[0]?.value ?? ""),
      owners: owners.map((context) => ({
        refs: context.refs,
        displayName: context.displayName
      }))
    };
  }

  function matchingEntry(refs, ownerNames) {
    const wanted = Shared.uniqueRefs(refs).map((ref) => ref.key);
    if (wanted.some((key) => state.blockedKeys.has(key))) {
      return Shared.findMatchingEntry(state.blocked, refs);
    }
    return Shared.findMatchingEntryByNames(state.blocked, ownerNames);
  }

  function bestAnchor(root) {
    if (!root) {
      return null;
    }
    return channelAnchorsFromElement(root)[0] || null;
  }

  function buttonHost(root, pageButton) {
    const anchor = bestAnchor(root);
    if (anchor) {
      return anchor.closest("ytd-channel-name, #channel-name, #owner-name, #author-text") || anchor.parentElement;
    }
    const linklessCreator = linklessLockupCreatorElements(root).find((element) => {
      return Boolean(Shared.cleanCreatorDisplayName(
        element.textContent || element.getAttribute("aria-label")
      ));
    });
    if (linklessCreator) {
      return linklessCreator.closest(".ytContentMetadataViewModelMetadataRow") ||
        linklessCreator.parentElement;
    }
    if (!pageButton) {
      return null;
    }
    return root.querySelector("#channel-name, h1, [class*='page-header-title']") || root;
  }

  function displayNameFromRoot(root, refs) {
    const channelAnchors = channelAnchorsFromElement(root);
    const sources = [
      (anchor) => anchor.textContent,
      (anchor) => anchor.getAttribute("aria-label"),
      (anchor) => anchor.getAttribute("title")
    ];

    for (const source of sources) {
      for (const anchor of channelAnchors) {
        const name = Shared.cleanCreatorDisplayName(source(anchor));
        if (name) {
          return name;
        }
      }
    }

    const linklessName = linklessLockupCreatorNames(root)[0];
    if (linklessName) {
      return linklessName;
    }

    return refs.find((ref) => ref.type === "handle")?.value ||
      refs[0]?.value ||
      "creator";
  }

  function isCreatorMenuTrigger(control) {
    if (!control) {
      return false;
    }
    const label = [
      control.getAttribute("aria-label"),
      control.getAttribute("title"),
      control.querySelector("button")?.getAttribute("aria-label")
    ].filter(Boolean).join(" ");
    const isShortsControl = Boolean(control.closest(
      "ytd-reel-video-renderer, yt-reel-player-overlay-view-model, reel-action-bar-view-model"
    ));
    return Boolean(control.closest("ytd-menu-renderer, yt-menu-renderer")) ||
      /action menu|more actions/i.test(label) ||
      (isShortsControl && /^more$/i.test(label.trim()));
  }

  function isPromotedContentRoot(root) {
    if (!root) {
      return false;
    }
    return Boolean(
      root.matches?.(PROMOTED_CONTENT_SELECTOR) ||
      root.closest?.(PROMOTED_CONTENT_SELECTOR) ||
      root.querySelector?.(PROMOTED_CONTENT_SELECTOR)
    );
  }

  function compactShortPath(root) {
    const value = root?.querySelector?.("a[href^='/shorts/']")?.getAttribute("href") || "";
    try {
      const path = new URL(value, location.href).pathname;
      return path.startsWith("/shorts/") ? path : "";
    } catch {
      return "";
    }
  }

  function compactShortLayoutItem(root) {
    return root?.closest?.(".ytGridShelfViewModelGridShelfItem") || root;
  }

  function reflowCompactShortShelf(root) {
    const shelf = root?.closest?.("grid-shelf-view-model");
    if (!shelf) {
      return;
    }
    const rows = [...shelf.querySelectorAll(".ytGridShelfViewModelGridShelfRow")];
    const items = rows.flatMap((row) => [...row.children].filter((child) =>
      child.classList.contains("ytGridShelfViewModelGridShelfItem")));
    if (rows.length === 0 || items.length === 0) {
      return;
    }

    if (!Number.isInteger(shelf.__channelFenceRowCapacity)) {
      shelf.__channelFenceRowCapacity = Math.max(...rows.map((row) => row.children.length), 1);
      shelf.__channelFenceNextOrder = 0;
    }
    for (const item of items) {
      if (!Number.isInteger(item.__channelFenceGridOrder)) {
        item.__channelFenceGridOrder = shelf.__channelFenceNextOrder;
        shelf.__channelFenceNextOrder += 1;
      }
    }

    const byOriginalOrder = (left, right) =>
      left.__channelFenceGridOrder - right.__channelFenceGridOrder;
    const visible = items.filter((item) =>
      !item.classList.contains("cf-hidden-by-channelfence")).sort(byOriginalOrder);
    const hidden = items.filter((item) =>
      item.classList.contains("cf-hidden-by-channelfence")).sort(byOriginalOrder);
    const ordered = [...visible, ...hidden];
    const capacity = shelf.__channelFenceRowCapacity;

    rows.forEach((row) => {
      row.classList.toggle("cf-compact-short-row-reflow", hidden.length > 0);
    });

    rows.forEach((row, rowIndex) => {
      const start = rowIndex * capacity;
      const end = rowIndex === rows.length - 1 ? ordered.length : start + capacity;
      const desired = ordered.slice(start, end);
      const current = [...row.children].filter((child) =>
        child.classList.contains("ytGridShelfViewModelGridShelfItem"));
      if (current.length === desired.length &&
        current.every((item, index) => item === desired[index])) {
        return;
      }
      desired.forEach((item) => row.append(item));
    });
  }

  function setCompactShortPending(root, pending) {
    compactShortLayoutItem(root)?.classList.toggle("cf-compact-short-pending", pending);
  }

  function setCompactShortHidden(root, hidden) {
    const target = compactShortLayoutItem(root);
    if (!target) {
      return;
    }
    root.classList.remove("cf-hidden-by-channelfence");
    target.classList.toggle("cf-hidden-by-channelfence", hidden);
    target.classList.remove("cf-compact-short-pending");
    reflowCompactShortShelf(target);
  }

  async function resolveCompactShortContext(path) {
    const cached = state.compactShortContexts.get(path);
    if (cached) {
      return cached;
    }
    const failedAt = state.compactShortFailures.get(path);
    if (failedAt && Date.now() - failedAt < 300000) {
      return null;
    }
    const activeLookup = state.compactShortLookups.get(path);
    if (activeLookup) {
      return activeLookup;
    }

    const lookup = (async () => {
      try {
        const endpoint = new URL("/oembed", location.origin);
        endpoint.searchParams.set("url", new URL(path, location.origin).href);
        endpoint.searchParams.set("format", "json");
        const response = await fetch(endpoint, {
          cache: "force-cache",
          credentials: "omit"
        });
        if (!response.ok) {
          throw new Error(`YouTube metadata request failed with ${response.status}`);
        }
        const metadata = await response.json();
        const displayName = Shared.cleanCreatorDisplayName(metadata?.author_name);
        const channelRef = Shared.normalizeChannelRef(metadata?.author_url);
        const refs = refsWithNameFallback(channelRef ? [channelRef] : [], displayName);
        if (!displayName || refs.length === 0) {
          throw new Error("YouTube metadata did not include a creator");
        }
        const context = { refs, displayName };
        state.compactShortContexts.set(path, context);
        state.compactShortFailures.delete(path);
        return context;
      } catch {
        state.compactShortFailures.set(path, Date.now());
        return null;
      } finally {
        state.compactShortLookups.delete(path);
      }
    })();
    state.compactShortLookups.set(path, lookup);
    return lookup;
  }

  function inspectCompactShortCreator(root) {
    const path = compactShortPath(root);
    if (!path || state.blocked.length === 0 || state.compactShortContexts.has(path)) {
      return;
    }
    const failedAt = state.compactShortFailures.get(path);
    if (failedAt && Date.now() - failedAt < 300000) {
      setCompactShortPending(root, false);
      return;
    }
    if (root.querySelector(COMPACT_SHORTS_SELECTOR)) {
      return;
    }
    setCompactShortPending(root, true);
    resolveCompactShortContext(path).finally(() => {
      setCompactShortPending(root, false);
      scheduleMutationElement(root);
    });
  }

  async function blockCompactShortCreator(root) {
    const path = compactShortPath(root);
    if (!path) {
      showToast("ChannelFence couldn't identify this Short.");
      return;
    }
    const buttons = buttonsOwnedByRoot(root);
    buttons.forEach((button) => {
      button.disabled = true;
      button.setAttribute("aria-busy", "true");
    });

    try {
      state.compactShortFailures.delete(path);
      const context = await resolveCompactShortContext(path);
      if (!context) {
        throw new Error("YouTube metadata did not include a creator");
      }

      if (!await blockCreator(context.refs, context.displayName, path)) {
        state.compactShortContexts.delete(path);
      }
    } catch {
      showToast("ChannelFence couldn't identify this creator. Try opening the Short first.");
    } finally {
      buttons.forEach((button) => {
        if (button.isConnected) {
          button.disabled = false;
          button.removeAttribute("aria-busy");
        }
      });
    }
  }

  function rememberMenuContext(event) {
    if (!state.enabled || !(event.target instanceof Element)) {
      return;
    }
    const control = event.target.closest(
      "button, yt-icon-button, tp-yt-paper-icon-button, button-view-model, [role='button']"
    );
    if (!isCreatorMenuTrigger(control)) {
      return;
    }

    let root = event.target.closest(CONTENT_SELECTOR);
    if (isPromotedContentRoot(root)) {
      state.pendingMenuContext = null;
      scheduleMenuScan();
      return;
    }
    let refs = root ? refsFromElement(root) : [];
    let ownerNames = root ? ownerNamesFromElement(root) : [];
    let displayName = root ? displayNameFromRoot(root, refs) : "";
    let owners = root ? ownerContextsFromElement(root) : [];

    if (!root && control.closest("ytd-watch-metadata, ytd-video-primary-info-renderer")) {
      const pageContext = currentPageContext();
      const owner = pageOwnerRoot();
      root = owner || control.closest("ytd-watch-metadata, ytd-video-primary-info-renderer");
      refs = pageContext.refs;
      ownerNames = owner ? ownerNamesFromElement(owner) : [];
      displayName = pageContext.displayName;
      owners = owner ? ownerContextsFromElement(owner) : [];
    }

    const deferredShort = Boolean(root?.matches?.(COMPACT_SHORTS_SELECTOR) &&
      compactShortPath(root) && refs.length === 0);
    if (deferredShort) {
      state.pendingMenuContext = {
        root,
        trigger: control,
        refs: [],
        ownerNames: [],
        displayName: "Shorts creator",
        owners: [],
        deferredShort: true,
        expiresAt: Date.now() + 5000
      };
      scheduleMenuScan();
      return;
    }

    refs = refsWithNameFallback(refs, displayName);
    if (refs.length === 0) {
      return;
    }
    state.pendingMenuContext = {
      root,
      trigger: control,
      refs,
      ownerNames,
      displayName,
      owners: owners.length > 0
        ? owners.map((context) => ({ refs: context.refs, displayName: context.displayName }))
        : [{ refs, displayName }],
      expiresAt: Date.now() + 5000
    };
    scheduleMenuScan();
  }

  function closeCreatorMenu() {
    document.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Escape",
      code: "Escape",
      bubbles: true,
      composed: true
    }));
  }

  function nativeMenuTextColor(host) {
    const nativeItem = [...host.querySelectorAll(
      "ytd-menu-service-item-renderer, yt-list-item-view-model, tp-yt-paper-item, [role='menuitem']"
    )].find((item) => !item.classList.contains("cf-menu-item"));
    if (!nativeItem) {
      return "";
    }

    const label = nativeItem.querySelector(
      "yt-formatted-string, .yt-core-attributed-string, #label, [class*='label'], [class*='text']"
    );
    for (const element of [label, nativeItem]) {
      if (!element) {
        continue;
      }
      const color = getComputedStyle(element).color;
      if (color && color !== "transparent" && color !== "rgba(0, 0, 0, 0)") {
        return color;
      }
    }
    return "";
  }

  function creatorMenuContextKey(context) {
    if (context.deferredShort) {
      return `short:${compactShortPath(context.root)}`;
    }
    const owners = context.owners?.length > 0
      ? context.owners
      : [{ refs: context.refs, displayName: context.displayName }];
    return owners.map((owner) => {
      const blocked = matchingEntry(owner.refs, [owner.displayName]) ? "blocked" : "open";
      return `${identityKey(owner.refs)}:${blocked}`;
    }).join("|");
  }

  function ensureCreatorMenuItems(popup) {
    if (!popup) {
      return;
    }
    const context = state.pendingMenuContext;
    if (!state.enabled || !context || context.expiresAt < Date.now()) {
      popup.querySelectorAll(".cf-menu-item").forEach((item) => item.remove());
      delete popup.dataset.cfMenuContextKey;
      state.pendingMenuContext = null;
      return;
    }

    const contextKey = creatorMenuContextKey(context);
    const existingItems = popup.querySelectorAll(".cf-menu-item");
    if (existingItems.length > 0 && popup.dataset.cfMenuContextKey === contextKey) {
      return;
    }
    existingItems.forEach((item) => item.remove());
    popup.dataset.cfMenuContextKey = contextKey;

    const host = popup.querySelector("#items, tp-yt-paper-listbox, [role='menu']") || popup;
    const menuTextColor = nativeMenuTextColor(host);
    if (context.deferredShort) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "cf-menu-item";
      button.setAttribute("role", "menuitem");
      button.setAttribute("aria-label", "Block this Short's creator with ChannelFence");
      if (menuTextColor) {
        button.style.setProperty("--cf-menu-text-color", menuTextColor);
      }

      const symbol = document.createElement("span");
      symbol.className = "cf-menu-item__symbol";
      symbol.setAttribute("aria-hidden", "true");
      symbol.textContent = "\u2298";

      const label = document.createElement("span");
      label.className = "cf-menu-item__label";
      label.textContent = "ChannelFence: Block creator";
      button.append(symbol, label);
      button.addEventListener("click", async (event) => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        state.pendingMenuContext = null;
        closeCreatorMenu();
        await blockCompactShortCreator(context.root);
      }, true);
      host.append(button);
      return;
    }

    const owners = context.owners?.length > 0
      ? context.owners
      : [{ refs: context.refs, displayName: context.displayName }];
    const showOwnerName = owners.length > 1;

    for (const owner of owners) {
      const existingEntry = matchingEntry(owner.refs, [owner.displayName]);
      const button = document.createElement("button");
      button.type = "button";
      button.className = "cf-menu-item";
      button.setAttribute("role", "menuitem");
      button.setAttribute("aria-label", existingEntry
        ? `Unblock ${owner.displayName} with ChannelFence`
        : `Block ${owner.displayName} with ChannelFence`);
      if (menuTextColor) {
        button.style.setProperty("--cf-menu-text-color", menuTextColor);
      }

      const symbol = document.createElement("span");
      symbol.className = "cf-menu-item__symbol";
      symbol.setAttribute("aria-hidden", "true");
      symbol.textContent = "⊘";

      const label = document.createElement("span");
      label.className = "cf-menu-item__label";
      label.textContent = existingEntry
        ? `ChannelFence: Unblock${showOwnerName ? ` ${owner.displayName}` : ""}`
        : `ChannelFence: Block${showOwnerName ? ` ${owner.displayName}` : ""}`;
      button.append(symbol, label);

      button.addEventListener("click", async (event) => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        state.pendingMenuContext = null;
        closeCreatorMenu();

        if (existingEntry) {
          await unblockCreator(existingEntry.aliases);
          showToast(`Unblocked ${Shared.labelForEntry(existingEntry)}`);
          return;
        }
        await blockCreator(owner.refs, owner.displayName);
      }, true);

      host.append(button);
    }
  }

  function processCreatorMenus() {
    document.querySelectorAll(MENU_POPUP_SELECTOR).forEach(ensureCreatorMenuItems);
  }

  function scheduleMenuScan() {
    if (state.menuScanScheduled) {
      return;
    }
    state.menuScanScheduled = true;
    requestAnimationFrame(() => {
      state.menuScanScheduled = false;
      processCreatorMenus();
    });
  }

  function buttonsOwnedByRoot(root) {
    return [...root.querySelectorAll(".cf-block-button")].filter((button) => {
      return button.__channelFenceRoot === root;
    });
  }

  function shortsActionsOwnedByRoot(root) {
    return [...root.querySelectorAll(".cf-shorts-action")].filter((action) => {
      return action.__channelFenceRoot === root;
    });
  }

  function identityKey(refs) {
    return Shared.uniqueRefs(refs).map((ref) => ref.key).sort().join("|");
  }

  function setAttributeIfChanged(element, name, value) {
    if (element.getAttribute(name) !== value) {
      element.setAttribute(name, value);
    }
  }

  function ensureBlockButton(root, pageButton, ownerContext) {
    if (!state.enabled || !root) {
      return;
    }
    const pageContext = pageButton ? currentPageContext() : null;
    const displayName = ownerContext?.displayName ||
      pageContext?.displayName ||
      displayNameFromRoot(root, []);
    const refs = ownerContext?.refs || refsWithNameFallback([
      ...refsFromElement(root),
      ...(pageContext?.refs || [])
    ], displayName);
    if (refs.length === 0) {
      return;
    }
    const key = identityKey(refs);
    const existingButton = buttonsOwnedByRoot(root)
      .find((button) => button.dataset.cfIdentity === key);
    if (existingButton) {
      existingButton.title = `Block ${displayName} with ChannelFence`;
      setAttributeIfChanged(existingButton, "aria-label", `Block ${displayName}`);
      if (ownerContext?.anchor?.isConnected &&
          existingButton.__channelFenceAnchor !== ownerContext.anchor) {
        ownerContext.anchor.insertAdjacentElement("afterend", existingButton);
        existingButton.__channelFenceAnchor = ownerContext.anchor;
      }
      return;
    }

    const host = ownerContext?.anchor?.parentElement || buttonHost(root, pageButton);
    if (!host || host.closest("#cf-hard-block-overlay")) {
      return;
    }

    const button = document.createElement("button");
    button.type = "button";
    button.className = "cf-block-button";
    button.dataset.cfIdentity = key;
    button.__channelFenceRoot = root;
    button.__channelFenceAnchor = ownerContext?.anchor || null;
    button.title = `Block ${displayName} with ChannelFence`;
    button.setAttribute("aria-label", `Block ${displayName}`);

    const symbol = document.createElement("span");
    symbol.className = "cf-block-button__symbol";
    symbol.setAttribute("aria-hidden", "true");
    symbol.textContent = "⊘";
    button.append(symbol);

    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();

      const freshOwners = ownerContextsFromElement(root);
      const freshOwner = ownerContext
        ? freshOwners.find((candidate) => candidate.anchor === ownerContext.anchor) ||
          freshOwners.find((candidate) => candidate.refs.some((ref) =>
            ownerContext.refs.some((previousRef) => previousRef.key === ref.key)))
        : null;
      const freshPageContext = pageButton && !ownerContext ? currentPageContext() : null;
      const freshDisplayName = freshOwner?.displayName ||
        freshPageContext?.displayName ||
        displayNameFromRoot(root, refs);
      const freshRefs = freshOwner?.refs || refsWithNameFallback([
        ...refsFromElement(root),
        ...(freshPageContext?.refs || [])
      ], freshDisplayName);
      await blockCreator(
        freshRefs,
        freshDisplayName
      );
    }, true);

    if (ownerContext?.anchor?.isConnected) {
      ownerContext.anchor.insertAdjacentElement("afterend", button);
    } else {
      host.append(button);
    }
  }

  function ensureCompactShortButton(root) {
    if (root.querySelector(COMPACT_SHORTS_SELECTOR)) {
      return;
    }
    const path = compactShortPath(root);
    const host = root.querySelector(
      ".shortsLockupViewModelHostOutsideMetadataMenu, [class*='MetadataMenu']"
    );
    if (!path || !host) {
      return;
    }

    const key = `short:${path}`;
    const existingButton = buttonsOwnedByRoot(root)
      .find((button) => button.dataset.cfIdentity === key);
    if (existingButton) {
      return;
    }

    buttonsOwnedByRoot(root).forEach((button) => button.remove());
    const button = document.createElement("button");
    button.type = "button";
    button.className = "cf-block-button cf-compact-shorts-block";
    button.dataset.cfIdentity = key;
    button.__channelFenceRoot = root;
    button.title = "Block this Short's creator with ChannelFence";
    button.setAttribute("aria-label", "Block this Short's creator with ChannelFence");

    const symbol = document.createElement("span");
    symbol.className = "cf-block-button__symbol";
    symbol.setAttribute("aria-hidden", "true");
    symbol.textContent = "\u2298";
    button.append(symbol);
    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      await blockCompactShortCreator(root);
    }, true);
    host.before(button);
  }

  function ensureShortsAction(root, ownerContext) {
    if (!state.enabled || !root || !ownerContext) {
      return;
    }

    const actionBar = root.querySelector("reel-action-bar-view-model");
    const refs = refsWithNameFallback(ownerContext.refs, ownerContext.displayName);
    if (!actionBar || refs.length === 0) {
      return;
    }

    const displayName = ownerContext.displayName || displayNameFromRoot(root, refs);
    const key = identityKey(refs);
    const ownedActions = shortsActionsOwnedByRoot(root);
    for (const action of ownedActions) {
      if (action.dataset.cfIdentity !== key) {
        action.remove();
      }
    }

    const existingAction = ownedActions.find((action) => action.dataset.cfIdentity === key);
    if (existingAction) {
      const existingButton = existingAction.querySelector(".cf-shorts-action__button");
      existingButton.title = `Block ${displayName} with ChannelFence`;
      setAttributeIfChanged(
        existingButton,
        "aria-label",
        `Block ${displayName} with ChannelFence`
      );
      if (existingAction.parentElement !== actionBar ||
          actionBar.firstElementChild !== existingAction) {
        actionBar.prepend(existingAction);
      }
      return;
    }

    const action = document.createElement("div");
    action.className = "cf-shorts-action";
    action.dataset.cfIdentity = key;
    action.__channelFenceRoot = root;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "cf-shorts-action__button";
    button.title = `Block ${displayName} with ChannelFence`;
    button.setAttribute("aria-label", `Block ${displayName} with ChannelFence`);

    const icon = document.createElement("img");
    icon.className = "cf-shorts-action__icon";
    icon.src = chrome.runtime.getURL("assets/icons/channelfence-48.png");
    icon.alt = "";
    icon.setAttribute("aria-hidden", "true");

    const label = document.createElement("span");
    label.className = "cf-shorts-action__label";
    label.setAttribute("aria-hidden", "true");
    label.textContent = "Block";

    button.append(icon);
    action.append(button, label);

    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();

      const freshOwners = ownerContextsFromElement(root);
      const freshOwner = freshOwners.find((candidate) => candidate.refs.some((ref) =>
        ownerContext.refs.some((previousRef) => previousRef.key === ref.key))) ||
        freshOwners[0] || ownerContext;
      await blockCreator(
        refsWithNameFallback(freshOwner.refs, freshOwner.displayName),
        freshOwner.displayName
      );
    }, true);

    actionBar.prepend(action);
  }

  function ensureOwnerButtons(root, pageButton) {
    const discoveredOwners = ownerContextsFromElement(root);
    const owners = discoveredOwners.filter((context) => {
      if (pageButton || !context.anchor) {
        return true;
      }
      return context.anchor.closest(`${CONTENT_SELECTOR},${COMMENT_SELECTOR}`) === root;
    });
    if (root.matches?.(COMPACT_SHORTS_SELECTOR)) {
      shortsActionsOwnedByRoot(root).forEach((action) => action.remove());
      ensureCompactShortButton(root);
      return;
    }
    if (discoveredOwners.length > 0 && owners.length === 0) {
      buttonsOwnedByRoot(root).forEach((button) => button.remove());
      shortsActionsOwnedByRoot(root).forEach((action) => action.remove());
      return;
    }

    const isCurrentShortsViewer = isShortsRoute() &&
      root.matches?.("ytd-reel-video-renderer");
    if (isCurrentShortsViewer) {
      buttonsOwnedByRoot(root).forEach((button) => button.remove());
      ensureShortsAction(root, owners[0] || null);
      return;
    }

    shortsActionsOwnedByRoot(root).forEach((action) => action.remove());
    const contexts = owners.length > 0 ? owners : [null];
    const expectedKeys = new Set(
      contexts.filter(Boolean).map((context) => identityKey(context.refs))
    );

    for (const button of buttonsOwnedByRoot(root)) {
      if (expectedKeys.size > 0 && !expectedKeys.has(button.dataset.cfIdentity)) {
        button.remove();
      }
    }
    for (const context of contexts) {
      ensureBlockButton(root, pageButton, context);
    }
  }

  function processItem(item, isComment) {
    if (!isComment && isPromotedContentRoot(item)) {
      item.classList.remove("cf-hidden-by-channelfence");
      item.querySelectorAll(".cf-block-button, .cf-shorts-action")
        .forEach((control) => control.remove());
      return;
    }
    const isCompactShort = Boolean(item.matches?.(COMPACT_SHORTS_SELECTOR));
    const compactPath = isCompactShort ? compactShortPath(item) : "";
    const compactContext = compactPath
      ? state.compactShortContexts.get(compactPath)
      : null;
    const exactShortEntry = compactPath
      ? state.blocked.find((entry) => entry.shortPaths?.includes(compactPath))
      : null;
    if (isCompactShort && !compactContext && !exactShortEntry) {
      inspectCompactShortCreator(item);
    }
    const refs = compactContext?.refs || refsFromElement(item);
    const ownerNames = compactContext?.displayName
      ? [compactContext.displayName]
      : ownerNamesFromElement(item);
    const blocked = Boolean(exactShortEntry || matchingEntry(refs, ownerNames));
    const isShortsViewer = isShortsRoute() && item.matches("ytd-reel-video-renderer");
    const shouldHide = state.enabled && blocked && (!isComment || state.hideComments) &&
      !isShortsViewer;
    if (isCompactShort) {
      if (!state.compactShortLookups.has(compactPath)) {
        setCompactShortHidden(item, shouldHide);
      }
    } else {
      item.classList.toggle("cf-hidden-by-channelfence", shouldHide);
    }

    if (!state.enabled || blocked) {
      item.querySelectorAll(".cf-block-button, .cf-shorts-action")
        .forEach((button) => button.remove());
      return;
    }
    ensureOwnerButtons(item, false);
  }

  function pauseVisibleVideos() {
    for (const video of document.querySelectorAll("video")) {
      try {
        video.pause();
      } catch {
        // A detached player can reject media operations during navigation.
      }
    }
  }

  function removeOverlay() {
    document.getElementById("cf-hard-block-overlay")?.remove();
  }

  function showOverlay(entry, refs) {
    clearWatchPending();
    pauseVisibleVideos();

    const existing = document.getElementById("cf-hard-block-overlay");
    if (existing?.dataset.mode === "creator" && existing.dataset.entryKey === entry.key) {
      return;
    }
    existing?.remove();

    const overlay = document.createElement("section");
    overlay.id = "cf-hard-block-overlay";
    overlay.dataset.mode = "creator";
    overlay.dataset.entryKey = entry.key;
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-labelledby", "cf-hard-block-title");

    const card = document.createElement("div");
    card.className = "cf-hard-block-card";

    const icon = document.createElement("div");
    icon.className = "cf-hard-block-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = "⊘";

    const title = document.createElement("h1");
    title.id = "cf-hard-block-title";
    title.textContent = "Creator blocked";

    const message = document.createElement("p");
    message.textContent = `${Shared.labelForEntry(entry)} is on your ChannelFence block list.`;

    const actions = document.createElement("div");
    actions.className = "cf-hard-block-actions";

    const home = document.createElement("button");
    home.type = "button";
    home.textContent = "Go to Home";
    home.addEventListener("click", () => location.assign("/"));

    const unblock = document.createElement("button");
    unblock.type = "button";
    unblock.textContent = "Unblock and continue";
    unblock.addEventListener("click", async () => {
      await unblockCreator(entry.aliases);
      removeOverlay();
      scheduleScan();
    });

    actions.append(home, unblock);
    card.append(icon, title, message, actions);
    overlay.append(card);
    (document.body || document.documentElement).append(overlay);
    home.focus();
  }

  function clearBlockedShortSkip() {
    clearTimeout(state.blockedShortSkipTimer);
    state.blockedShortSkipTimer = null;
    state.blockedShortSkipKey = "";
  }

  function advancePastBlockedShort(entry) {
    const sourceUrl = location.href;
    const skipKey = `${sourceUrl}|${entry.key}`;
    clearWatchPending();
    removeOverlay();

    if (state.blockedShortSkipKey === skipKey) {
      return;
    }
    clearBlockedShortSkip();
    state.blockedShortSkipKey = skipKey;

    const scroller = document.querySelector("ytd-shorts #shorts-container");
    if (scroller) {
      scroller.scrollBy({
        top: Math.max(scroller.clientHeight, 640),
        behavior: "smooth"
      });
    }

    state.blockedShortSkipTimer = setTimeout(() => {
      if (location.href === sourceUrl) {
        location.assign("/");
      }
    }, 2500);
  }

  function applyRouteGuard() {
    if (state.navigationInProgress) {
      removeOverlay();
      return;
    }

    if (!state.enabled) {
      clearBlockedShortSkip();
      clearWatchPending();
      removeOverlay();
      return;
    }

    const context = currentPageContext();
    const pathIsChannel = Boolean(Shared.normalizeChannelRef(location.href));
    const routeNeedsIdentity = pathIsChannel || isWatchLikeRoute();
    if (!routeNeedsIdentity) {
      clearWatchPending();
      removeOverlay();
      return;
    }

    const entry = matchingEntry(context.refs);
    if (entry) {
      if (isShortsRoute()) {
        advancePastBlockedShort(entry);
        return;
      }
      showOverlay(entry, context.refs);
      return;
    }

    if (state.blockedShortSkipKey) {
      clearBlockedShortSkip();
    }

    removeOverlay();
    if (pathIsChannel || context.refs.length > 0) {
      clearWatchPending();
    }

    const owner = pageOwnerRoot();
    if (owner) {
      ensureOwnerButtons(owner, true);
    }
  }

  function pathFromElement(element) {
    if (!element) {
      return "";
    }
    const anchor = element.matches?.("a") ? element : element.querySelector?.("a");
    const value = anchor?.href || anchor?.getAttribute?.("href") || "";
    try {
      return new URL(value, location.href).pathname;
    } catch {
      return "";
    }
  }

  function hasDirectShortsLink(root) {
    if (!root) {
      return false;
    }
    const anchors = root.matches?.("a") ? [root] : [...root.querySelectorAll("a")];
    return anchors.some((anchor) => pathFromElement(anchor).startsWith("/shorts/"));
  }

  function clearHiddenShorts(root = document) {
    const items = [];
    if (root instanceof Element && root.matches(".cf-hidden-shorts-by-channelfence")) {
      items.push(root);
    }
    root.querySelectorAll?.(".cf-hidden-shorts-by-channelfence").forEach((item) => {
      items.push(item);
    });
    items.forEach((item) => item.classList.remove("cf-hidden-shorts-by-channelfence"));
  }

  function shouldHideShortsItem(item) {
    if (!state.enabled || !state.hideHomeShorts || isShortsRoute()) {
      return false;
    }
    if (item.matches("ytd-rich-section-renderer")) {
      return Boolean(item.querySelector(SHORTS_SHELF_SELECTOR)) || hasDirectShortsLink(item);
    }
    if (item.matches(SHORTS_SHELF_SELECTOR)) {
      const knownShortsShelf = item.matches(
        "ytd-reel-shelf-renderer, ytd-rich-shelf-renderer[is-shorts], " +
        "yt-horizontal-list-renderer[is-shorts]"
      );
      return knownShortsShelf || hasDirectShortsLink(item);
    }
    return item.matches(SHORTS_CARD_SELECTOR) && hasDirectShortsLink(item);
  }

  function processShortsVisibilityWithin(root) {
    const items = new Set();
    if (root instanceof Element && root.matches(SHORTS_VISIBILITY_SELECTOR)) {
      items.add(root);
    }
    root.querySelectorAll?.(SHORTS_VISIBILITY_SELECTOR).forEach((item) => items.add(item));
    for (const item of items) {
      item.classList.toggle(
        "cf-hidden-shorts-by-channelfence",
        shouldHideShortsItem(item)
      );
    }
  }

  function processShortsVisibility() {
    processShortsVisibilityWithin(document);
  }

  function scan() {
    state.scanScheduled = false;
    state.mutationRoots.clear();
    state.mutationShortsRoots.clear();
    state.mutationRouteDirty = false;

    if (location.href !== state.currentUrl) {
      state.currentUrl = location.href;
      clearBlockedShortSkip();
      removeOverlay();
      markWatchPending();
    }

    if (!state.enabled) {
      document.querySelectorAll(".cf-hidden-by-channelfence").forEach((item) => {
        item.classList.remove("cf-hidden-by-channelfence");
      });
      document.querySelectorAll(".cf-compact-short-pending").forEach((item) => {
        item.classList.remove("cf-compact-short-pending");
      });
      document.querySelectorAll("grid-shelf-view-model").forEach(reflowCompactShortShelf);
      document.querySelectorAll(".cf-block-button").forEach((button) => button.remove());
      document.querySelectorAll(".cf-shorts-action").forEach((action) => action.remove());
      document.querySelectorAll(".cf-menu-item").forEach((button) => button.remove());
      clearHiddenShorts();
      state.pendingMenuContext = null;
      applyRouteGuard();
      return;
    }

    processShortsVisibility();
    document.querySelectorAll(CONTENT_SELECTOR).forEach((item) => processItem(item, false));
    document.querySelectorAll(COMMENT_SELECTOR).forEach((item) => processItem(item, true));
    processCreatorMenus();
    applyRouteGuard();
  }

  function scheduleScan() {
    if (state.scanScheduled) {
      return;
    }
    state.scanScheduled = true;
    requestAnimationFrame(scan);
  }

  const CHANNELFENCE_ELEMENT_SELECTOR = [
    ".cf-block-button",
    ".cf-shorts-action",
    ".cf-menu-item",
    "#cf-toast",
    "#cf-hard-block-overlay"
  ].join(",");

  function isChannelFenceNode(node) {
    const element = node instanceof Element ? node : node?.parentElement;
    return Boolean(element?.closest?.(CHANNELFENCE_ELEMENT_SELECTOR));
  }

  function addMutationRoots(element, selector, collection, includeDescendants) {
    const closest = element.closest?.(selector);
    if (closest) {
      collection.add(closest);
    }
    if (element.matches?.(selector)) {
      collection.add(element);
    }
    if (includeDescendants) {
      element.querySelectorAll?.(selector).forEach((root) => collection.add(root));
    }
  }

  function scheduleMutationFlush() {
    if (state.mutationScanScheduled || state.scanScheduled) {
      return;
    }
    state.mutationScanScheduled = true;
    requestAnimationFrame(flushMutationScan);
  }

  function scheduleMutationElement(element, includeDescendants = false) {
    if (!(element instanceof Element) || isChannelFenceNode(element)) {
      return;
    }

    addMutationRoots(
      element,
      MUTATION_ROOT_SELECTOR,
      state.mutationRoots,
      includeDescendants
    );
    addMutationRoots(
      element,
      SHORTS_VISIBILITY_SELECTOR,
      state.mutationShortsRoots,
      includeDescendants
    );

    const pageOwnerChanged = routeHasCurrentCreator() && Boolean(
      element.closest?.(PAGE_OWNER_SELECTOR) ||
      element.matches?.(PAGE_OWNER_SELECTOR) ||
      (includeDescendants && element.querySelector?.(PAGE_OWNER_SELECTOR)) ||
      element.matches?.("meta[itemprop='channelId']") ||
      (includeDescendants && element.querySelector?.("meta[itemprop='channelId']"))
    );
    if (pageOwnerChanged) {
      state.mutationRouteDirty = true;
    }
    scheduleMutationFlush();
  }

  function flushMutationScan() {
    state.mutationScanScheduled = false;
    if (state.scanScheduled) {
      return;
    }

    const roots = [...state.mutationRoots];
    const shortsRoots = [...state.mutationShortsRoots];
    const routeDirty = state.mutationRouteDirty;
    state.mutationRoots.clear();
    state.mutationShortsRoots.clear();
    state.mutationRouteDirty = false;

    shortsRoots.filter((root) => root.isConnected)
      .forEach((root) => processShortsVisibilityWithin(root));
    for (const root of roots) {
      if (!root.isConnected) {
        continue;
      }
      if (root.matches(MENU_POPUP_SELECTOR)) {
        ensureCreatorMenuItems(root);
      } else if (root.matches(COMMENT_SELECTOR)) {
        processItem(root, true);
      } else if (root.matches(CONTENT_SELECTOR)) {
        processItem(root, false);
      }
    }
    if (routeDirty) {
      applyRouteGuard();
    }
  }

  async function blockCreator(refs, displayName, shortPath) {
    const entry = Shared.createBlockedEntry(
      refs,
      displayName,
      undefined,
      shortPath ? [shortPath] : []
    );
    if (!entry) {
      showToast("ChannelFence couldn't identify this creator yet.");
      return false;
    }
    state.blocked = Shared.mergeBlockedEntry(state.blocked, entry);
    rebuildBlockedKeys();
    await chrome.storage.local.set({ [Shared.STORAGE.blocked]: state.blocked });
    showToast(`Blocked ${Shared.labelForEntry(entry)}`, {
      label: "Undo",
      action: () => unblockCreator(entry.aliases)
    });
    scheduleScan();
    return true;
  }

  async function unblockCreator(refs) {
    state.blocked = Shared.removeEntriesMatchingRefs(state.blocked, refs);
    rebuildBlockedKeys();
    await chrome.storage.local.set({ [Shared.STORAGE.blocked]: state.blocked });
    scheduleScan();
  }

  function showToast(message, action) {
    clearTimeout(state.toastTimer);
    document.getElementById("cf-toast")?.remove();

    const toast = document.createElement("div");
    toast.id = "cf-toast";
    toast.setAttribute("role", "status");

    const text = document.createElement("span");
    text.textContent = message;
    toast.append(text);

    if (action) {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = action.label;
      button.addEventListener("click", async () => {
        toast.remove();
        await action.action();
      });
      toast.append(button);
    }

    (document.body || document.documentElement).append(toast);
    state.toastTimer = setTimeout(() => toast.remove(), 6000);
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") {
      return;
    }
    if (changes[Shared.STORAGE.enabled]) {
      state.enabled = changes[Shared.STORAGE.enabled].newValue !== false;
    }
    if (changes[Shared.STORAGE.hideComments]) {
      state.hideComments = changes[Shared.STORAGE.hideComments].newValue !== false;
    }
    if (changes[Shared.STORAGE.hideHomeShorts]) {
      state.hideHomeShorts = changes[Shared.STORAGE.hideHomeShorts].newValue === true;
    }
    if (changes[Shared.STORAGE.blocked]) {
      state.blocked = changes[Shared.STORAGE.blocked].newValue || [];
      rebuildBlockedKeys();
    }
    if (changes[Shared.STORAGE.enabled] || changes[Shared.STORAGE.blocked]) {
      requestActionUpdate();
    }
    scheduleScan();
  });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || message.type !== "CF_GET_PAGE_CONTEXT") {
      return false;
    }
    const context = currentPageContext();
    sendResponse({
      ok: context.refs.length > 0,
      refs: context.refs,
      displayName: context.displayName,
      owners: context.owners,
      blocked: Boolean(matchingEntry(context.refs))
    });
    return false;
  });

  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      const target = mutation.target instanceof Element
        ? mutation.target
        : mutation.target.parentElement;
      if (!target || isChannelFenceNode(target)) {
        continue;
      }

      if (mutation.type === "attributes") {
        scheduleMutationElement(target);
        continue;
      }

      const changedNodes = [...mutation.addedNodes, ...mutation.removedNodes]
        .filter((node) => !isChannelFenceNode(node));
      if (changedNodes.length === 0) {
        continue;
      }
      scheduleMutationElement(target);
      changedNodes.forEach((node) => {
        if (node instanceof Element) {
          scheduleMutationElement(node, true);
        }
      });
    }
  });
  observer.observe(document.documentElement, {
    attributeFilter: ["href", "aria-label", "title", "is-active"],
    attributes: true,
    childList: true,
    subtree: true
  });

  document.addEventListener("pointerdown", rememberMenuContext, true);
  document.addEventListener("click", rememberMenuContext, true);

  document.addEventListener("yt-navigate-start", () => {
    state.navigationInProgress = true;
    state.pendingMenuContext = null;
    removeOverlay();
    markWatchPending();
  }, true);
  document.addEventListener("yt-navigate-finish", () => {
    state.navigationInProgress = false;
    scheduleScan();
  }, true);
  document.addEventListener("yt-page-data-updated", (event) => {
    if (event.target instanceof Element && event.target !== document.documentElement) {
      scheduleMutationElement(event.target);
      state.mutationRouteDirty = true;
      scheduleMutationFlush();
      return;
    }
    scheduleScan();
  }, true);
  window.addEventListener("popstate", scheduleScan, true);

  initializeState();
})();
